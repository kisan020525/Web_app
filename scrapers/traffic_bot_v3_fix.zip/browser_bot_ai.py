
import time
import os
import sys
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from colorama import init, Fore, Style
import google.generativeai as genai
from dotenv import load_dotenv

# Initialize Colorama
init()
load_dotenv()

# --- CONFIGURATION ---
MODEL_NAME = "gemini-2.5-flash-lite"
TARGET_SUBREDDITS = ["marketing", "smallbusiness", "entrepreneur", "emailmarketing"]
SEARCH_KEYWORDS = ["Mailchimp pricing", "Mailchimp expensive", "Mailchimp alternatives", "best email marketing"]

def print_status(message, status="INFO"):
    colors = {
        "INFO": Fore.CYAN,
        "SUCCESS": Fore.GREEN,
        "WARNING": Fore.YELLOW,
        "ERROR": Fore.RED,
        "BRAIN": Fore.MAGENTA
    }
    print(f"{colors.get(status, Fore.WHITE)}[{status}] {message}{Style.RESET_ALL}")

def setup_gemini():
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        print_status("GEMINI_API_KEY not found in .env", "WARNING")
        api_key = input(f"{Fore.YELLOW}Please paste your Google Gemini API Key here: {Style.RESET_ALL}").strip()
    
    if not api_key:
        print_status("No API Key provided. Exiting.", "ERROR")
        sys.exit(1)
        
    genai.configure(api_key=api_key)
    try:
        model = genai.GenerativeModel(MODEL_NAME)
        print_status(f"Connected to Brain: {MODEL_NAME}", "SUCCESS")
        return model
    except Exception as e:
        print_status(f"Failed to connect to AI: {e}", "ERROR")
        sys.exit(1)

def generate_reply(model, post_title, post_body=""):
    print_status("Reading post content...", "BRAIN")
    
    prompt = f"""
    You are a helpful, expert community member (not a bot).
    
    **Context:**
    A user on Reddit posted about Email Marketing.
    Title: "{post_title}"
    Body: "{post_body}"
    
    **Your Goal:**
    Write a helpful, empathetic comment.
    If (and ONLY if) they are complaining about pricing, contacts limits, or looking for alternatives to Mailchimp, recommend "Brevo" as the better alternative for 2025.
    
    **Key Selling Point to Mention:**
    Mailchimp charges for stored contacts (even inactive ones).
    Brevo allows UNLIMITED contacts and only charges for emails sent.
    
    **Mandatory:** 
    Include this link for the math breakdown: angyone.cloud/comparisons/brevo-vs-mailchimp/
    
    **Tone:**
    Casual, short, helpful. No "marketing speak". No hashtags.
    Max 3 sentences.
    """
    
    try:
        response = model.generate_content(prompt)
        reply_text = response.text.strip()
        print_status(f"Thought generated: '{reply_text[:50]}...'", "BRAIN")
        return reply_text
    except Exception as e:
        print_status(f"Thinking failed: {e}", "ERROR")
        return None

def start_smart_bot():
    model = setup_gemini()
    
    print_status("Launching Browser...", "INFO")
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-notifications")
    
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    
    try:
        # 1. Login
        driver.get("https://www.reddit.com/login/")
        print_status("Please Log In manually in the browser.", "WARNING")
        input(f"{Fore.YELLOW}Press ENTER after you are logged in...{Style.RESET_ALL}")
        
        # 2. Hunt
        for keyword in SEARCH_KEYWORDS:
            print_status(f"Hunting for: '{keyword}'", "INFO")
            search_url = f"https://www.reddit.com/search/?q={keyword.replace(' ', '%20')}&t=week"
            driver.get(search_url)
            time.sleep(3)
            
            # Find posts (This selector is generic, Reddit changes classes often. 
            # Ideally getting hrefs is safer)
            links = driver.find_elements(By.TAG_NAME, "a")
            post_urls = []
            for link in links:
                href = link.get_attribute("href")
                if href and "/r/" in href and "/comments/" in href:
                    post_urls.append(href)
            
            # De-duplicate
            post_urls = list(set(post_urls))[:5] # Check top 5 relevant
            
            print_status(f"Found {len(post_urls)} potential leads.", "INFO")
            
            for url in post_urls:
                print_status(f"Analyzing: {url}", "INFO")
                driver.get(url)
                time.sleep(3)
                
                # Extract Text
                try:
                    title_element = driver.find_element(By.TAG_NAME, "h1")
                    title_text = title_element.text
                    
                    # Brain decides
                    reply = generate_reply(model, title_text)
                    
                    if reply:
                        print(f"\n{Fore.GREEN}---------------------------------------------------")
                        print(f"PROPOSED REPLY:\n{reply}")
                        print(f"---------------------------------------------------{Style.RESET_ALL}\n")
                        
                        action = input("Type 'y' to POST this, 's' to SKIP: ")
                        if action.lower() == 'y':
                            # Click Comment Box (This is the tricky part - selectors vary)
                            # Attempting a generic approach for the main comment box
                            try:
                                from selenium.webdriver.common.action_chains import ActionChains
                                actions = ActionChains(driver)

                                # Strategy 1: Look for "Reply" button to open the box (common in new Reddit)
                                try:
                                    reply_triggers = driver.find_elements(By.XPATH, "//button[contains(text(), 'Reply')] | //div[contains(text(), 'Reply')]")
                                    if reply_triggers:
                                        # Click the last one found (usually the main post reply, not nested)
                                        reply_triggers[-1].click()
                                        time.sleep(1)
                                except:
                                    pass # Box might already be open

                                # Strategy 2: Find the Editor (Rich Text or Markdown)
                                comment_box = None
                                try:
                                    # Rich Text Editor
                                    comment_box = driver.find_element(By.CSS_SELECTOR, "div[contenteditable='true']")
                                except:
                                    try:
                                        # Markdown Mode
                                        comment_box = driver.find_element(By.TAG_NAME, "textarea")
                                    except:
                                        pass

                                if comment_box:
                                    comment_box.click()
                                    time.sleep(0.5)
                                    # Use ActionChains for safer typing
                                    actions.move_to_element(comment_box).click().pause(0.5).send_keys(reply).perform()
                                    
                                    print_status("Message auto-typed! Please review and click 'Comment'.", "SUCCESS")
                                    
                                    # Optional: Highlight the Submit button
                                    try:
                                        submit_btn = driver.find_element(By.CSS_SELECTOR, "button[type='submit']")
                                        driver.execute_script("arguments[0].style.border='3px solid red'", submit_btn)
                                    except:
                                        pass
                                else:
                                    raise Exception("Could not find comment box.")

                            except Exception as e:
                                print_status(f"Could not auto-type: {e}. Copy/Paste manual fallback!", "ERROR")
                        else:
                            print_status("Skipped.", "INFO")
                            
                except Exception as e:
                    print_status(f"Skipping post (read error): {e}", "WARNING")
                
                time.sleep(2)

    except Exception as e:
        print_status(f"Bot Cash: {e}", "ERROR")
        
    finally:
        print_status("Closing session.", "INFO")
        driver.quit()

if __name__ == "__main__":
    start_smart_bot()
