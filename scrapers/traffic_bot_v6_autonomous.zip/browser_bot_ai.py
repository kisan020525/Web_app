
import time
import os
import sys
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from colorama import init, Fore, Style
import google.generativeai as genai
from dotenv import load_dotenv

# Initialize Colorama
init()
load_dotenv()

# --- CONFIGURATION ---
MODEL_NAME = "gemini-2.5-flash-lite"
TARGET_SUBREDDITS = ["marketing", "smallbusiness", "entrepreneur", "emailmarketing"]
SEARCH_KEYWORDS = ["Mailchimp pricing", "Mailchimp expensive", "Mailchimp alternatives", "best email marketing"]

def print_status(message, status="INFO"):
    colors = {
        "INFO": Fore.CYAN,
        "SUCCESS": Fore.GREEN,
        "WARNING": Fore.YELLOW,
        "ERROR": Fore.RED,
        "BRAIN": Fore.MAGENTA,
        "ACTION": Fore.BLUE
    }
    print(f"{colors.get(status, Fore.WHITE)}[{status}] {message}{Style.RESET_ALL}")

def setup_gemini():
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        print_status("GEMINI_API_KEY not found in .env", "WARNING")
        sys.exit(1)
        
    genai.configure(api_key=api_key)
    try:
        model = genai.GenerativeModel(MODEL_NAME)
        print_status(f"Connected to Brain: {MODEL_NAME}", "SUCCESS")
        return model
    except Exception as e:
        print_status(f"Failed to connect to AI: {e}", "ERROR")
        sys.exit(1)

def generate_reply(model, post_title, post_body=""):
    print_status("Reading post content...", "BRAIN")
    
    prompt = f"""
    You are representing "AngyOne", a helpful resource for marketers.
    
    **Your Knowledge Base:**
    1.  **Main Comparison:** angyone.cloud/comparisons/brevo-vs-mailchimp/
        *   BEST FOR: Complaints about Mailchimp pricing, contacts limits, or "expensive".
        *   KEY FACT: Mailchimp charges for *storage* (inactive contacts). Brevo charges for *sending* (unlimited storage).
    2.  **Guide Hub:** angyone.cloud/guides/
        *   BEST FOR: General questions about how to start email marketing or strategy.
    
    **Context:**
    Reddit Post Title: "{post_title}"
    Reddit Post Body: "{post_body}"
    
    **Task:**
    Decide if we should reply.
    *   IF the user is complaining about cost/limits: Reply with EMPATHY + BREVO RECOMENDATION + COMPARISON LINK.
    *   IF the user is just asking for general advice: Reply with STRATEGY + GUIDE LINK.
    *   IF irrelevant/spam: Reply with "SKIP".
    
    **Output Format:**
    Just the comment text. Nothing else.
    If skipping, just output "SKIP".
    """
    
    try:
        response = model.generate_content(prompt)
        reply_text = response.text.strip()
        print_status(f"Thought generated: '{reply_text[:50]}...'", "BRAIN")
        return reply_text
    except Exception as e:
        print_status(f"Thinking failed: {e}", "ERROR")
        return "SKIP"

def find_and_interact_comment_box(driver, actions, wait):
    # 1. Try to "Open" the box (Click 'Add a comment' placeholder)
    try:
        print_status("Checking for 'Add a comment' placeholder...", "INFO")
        placeholders = driver.find_elements(By.XPATH, "//div[contains(text(), 'Add a comment')]")
        if placeholders:
            for p in placeholders:
                if p.is_displayed():
                    p.click()
                    print_status("Clicked placeholder.", "INFO")
                    time.sleep(5)
                    break
    except:
        pass

    # 2. Find the Actual Editor (ContentEditable)
    print_status("Hunting for Text Editor...", "INFO")
    
    # Priority 1: Rich Text Div (contenteditable=true)
    try:
        element = wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, "div[contenteditable='true']")))
        print_status(f"Found Editor: {element.tag_name}", "SUCCESS")
        return element
    except:
        pass
        
    # Priority 2: Textarea (Markdown mode) - MUST BE VISIBLE
    try:
        textareas = driver.find_elements(By.TAG_NAME, "textarea")
        for ta in textareas:
            if ta.is_displayed() and ta.get_attribute("disabled") is None:
                print_status("Found Visible Textarea.", "SUCCESS")
                return ta
    except:
        pass

    # Priority 3: Role=MessageBox
    try:
        element = driver.find_element(By.XPATH, "//*[@role='textbox']")
        if element.is_displayed():
             print_status("Found Role=Textbox.", "SUCCESS")
             return element
    except:
        pass

    return None

def start_smart_bot():
    model = setup_gemini()
    
    print_status("Launching Autonomous Browser...", "INFO")
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-notifications")
    
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    wait = WebDriverWait(driver, 10)
    actions = ActionChains(driver)

    try:
        # 1. Login
        driver.get("https://www.reddit.com/login/")
        print_status("Please Log In manually in the browser.", "WARNING")
        input(f"{Fore.YELLOW}Press ENTER after you are logged in...{Style.RESET_ALL}")
        
        # 2. Hunt
        while True: # Infinite Loop for 24/7 Running
            for keyword in SEARCH_KEYWORDS:
                print_status(f"Hunting for: '{keyword}'", "INFO")
                try:
                    search_url = f"https://www.reddit.com/search/?q={keyword.replace(' ', '%20')}&t=week"
                    driver.get(search_url)
                    time.sleep(10) # Wait for results
                    
                    # Find links
                    links = driver.find_elements(By.TAG_NAME, "a")
                    post_urls = []
                    for link in links:
                        href = link.get_attribute("href")
                        if href and "/r/" in href and "/comments/" in href:
                            post_urls.append(href)
                    
                    post_urls = list(set(post_urls))[:5] # Top 5
                    
                    for url in post_urls:
                        print_status(f"Analyzing: {url}", "INFO")
                        driver.get(url)
                        time.sleep(10) # Let post load
                        
                        try:
                            title_element = driver.find_element(By.TAG_NAME, "h1")
                            title_text = title_element.text
                            
                            # Brain Decides
                            reply = generate_reply(model, title_text)
                            
                            if reply and "SKIP" not in reply:
                                print_status("DECISION: POSTING COMMENT", "SUCCESS")
                                
                                # Find Box
                                comment_box = find_and_interact_comment_box(driver, actions, wait)
                                
                                if comment_box:
                                    # Force Focus
                                    driver.execute_script("arguments[0].focus();", comment_box)
                                    time.sleep(2)
                                    comment_box.click() 
                                    time.sleep(2)
                                    
                                    # Type
                                    print_status("Typing...", "ACTION")
                                    actions.move_to_element(comment_box).click().send_keys(reply).perform()
                                    time.sleep(5)
                                    
                                    # Submit
                                    submit_btns = driver.find_elements(By.CSS_SELECTOR, "button[type='submit']")
                                    clicked = False
                                    for btn in submit_btns:
                                        if btn.is_displayed() and "comment" in btn.text.lower():
                                            print_status("Clicking Reply Button...", "ACTION")
                                            btn.click()
                                            clicked = True
                                            break
                                    
                                    if not clicked:
                                        # Fallback for icon-only buttons
                                        if submit_btns:
                                           submit_btns[-1].click() # Try the last submit button
                                           print_status("Clicked fallback submit button.", "WARNING")

                                    print_status("Wait 60s before next post...", "INFO")
                                    time.sleep(60) # Safety Delay
                                else:
                                    print_status("Could not find box. Skipping.", "ERROR")
                            else:
                                print_status("DECISION: SKIP", "INFO")
                                
                        except Exception as e:
                            print_status(f"Analysis Failed: {e}", "WARNING")
                        
                        time.sleep(5)
                        
                except Exception as e:
                     print_status(f"Search Loop Error: {e}", "ERROR")
                     time.sleep(10)
            
            print_status("Cycle Complete. Sleeping 5 mins...", "INFO")
            time.sleep(300)

    except Exception as e:
        print_status(f"Bot Fatal Error: {e}", "ERROR")
        
    finally:
        print_status("Closing session.", "INFO")
        driver.quit()

if __name__ == "__main__":
    start_smart_bot()
